import{r as n,a7 as e,ae as xe,bn as be,ch as M,af as Te,a_ as Ae,aP as Pe,bw as Ie,aZ as Re,bA as Ee,as as W,aq as Be,aK as Oe,bv as qe,bb as Fe,c3 as Ue,ci as Me,aa as We,aQ as fe}from"./vendor-core-CJH-FF0i.js";import{u as Ve,e as Je,M as Ke,C as _,B as C,b as V}from"./index-toXKTWds.js";import{B as J}from"./Badge-BWdZPZcB.js";const ts=({isOpen:b,onClose:I,order:t,onEdit:K})=>{const[R,Z]=n.useState([]),[ye,G]=n.useState(!1),[H,Q]=n.useState(!1),[f,y]=n.useState(""),[ve,X]=n.useState(null),[E,Y]=n.useState(!1),[u,B]=n.useState("details"),[z,ee]=n.useState(()=>{try{const s=localStorage.getItem("orderflow_custom_notes_templates");return s?JSON.parse(s):[]}catch{return[]}}),[Ze,Ge]=n.useState(""),[He,Qe]=n.useState(!1),se=s=>{f.trim()?y(a=>a.trim()+`
`+s):y(s)},je=(s,a)=>{a.stopPropagation();const i=z.filter((o,c)=>c!==s);ee(i),localStorage.setItem("orderflow_custom_notes_templates",JSON.stringify(i))},[p,D]=n.useState(null),[O,j]=n.useState(""),[N,te]=n.useState(!1),[ae,h]=n.useState(""),[Ne,ie]=n.useState(null),S=n.useRef(null),k=n.useRef(null),{user:v,profile:re,userRoles:ne}=Ve(),{checkPhone:q,getRatio:Se}=Je(),r=Ne||t,le=async()=>{if(t?.id){G(!0);try{const s=await V.getOrderActivity(t.id);Z(s||[])}catch(s){console.error("Failed to fetch activity logs:",s)}finally{G(!1)}}};if(n.useEffect(()=>{if(b&&t?.id){const s=JSON.parse(localStorage.getItem("premium_search_viewed")||"[]"),i=[{id:t.id,label:t.customer_name||"Unnamed Order",sub:`#${t.id.replace("ORD-","")}`,type:"order"},...s.filter(o=>o.id!==t.id)].slice(0,10);localStorage.setItem("premium_search_viewed",JSON.stringify(i)),ie(null),D(null),h(""),B("details"),le()}else Z([])},[b,t?.id]),n.useEffect(()=>{y(String(t?.notes||"")),X(null)},[t?.id,t?.notes,b]),n.useEffect(()=>{b&&t?.phone&&q(t.phone)},[b,t?.phone,q]),n.useEffect(()=>()=>{S.current&&window.clearTimeout(S.current)},[]),n.useEffect(()=>{p&&k.current&&(k.current.focus(),k.current.select?.())},[p]),!r)return null;const ke=s=>{const a=String(s==="delivery_charge"?Number(r?.delivery_charge)||Number(r?.pricing_summary?.delivery_charge)||0:r?.[s]||"");D(s),j(a),h("")},ce=()=>{D(null),j(""),h("")},oe=async()=>{if(!r?.id||!v?.id)return;const s=O.trim();if(!s){h("Value cannot be empty.");return}if(p==="delivery_charge"&&isNaN(Number(s))){h("Must be a valid number.");return}te(!0),h("");try{const a=p==="delivery_charge"?{delivery_charge:Number(s)}:{[p]:s},i=re?.name||v?.email||"Unknown User";await V.updateOrder(r.id,a,v.id,i,ne),ie(o=>({...o||r,...a})),D(null),j(""),await le()}catch(a){console.error("[OrderDetailsModal] saveField failed:",a),h(a.message||"Save failed. Try again.")}finally{te(!1)}},de=s=>{s.key==="Enter"&&p!=="address"&&oe(),s.key==="Escape"&&ce()},F=({field:s,label:a,icon:i,type:o="text",multiline:c=!1})=>{const w=p===s,d=s==="delivery_charge"?Number(r?.delivery_charge)||Number(r?.pricing_summary?.delivery_charge)||null:r?.[s],U=d!=null&&d!==""?d:"—";return e.jsxs("div",{className:`info-item${c?" vertical":""}`,children:[e.jsx("span",{className:"info-label",children:a}),w?e.jsxs("div",{className:"odm-inline-edit-wrap",children:[c?e.jsx("textarea",{ref:k,className:"odm-inline-input odm-inline-textarea",value:O,onChange:m=>j(m.target.value),onKeyDown:de,rows:3,disabled:N}):e.jsx("input",{ref:k,type:o,className:"odm-inline-input",value:O,onChange:m=>j(m.target.value),onKeyDown:de,disabled:N}),ae&&e.jsx("span",{className:"odm-field-error",children:ae}),e.jsxs("div",{className:"odm-inline-actions",children:[e.jsx("button",{className:"odm-save-btn",onClick:oe,disabled:N,children:N?"Saving...":"✓ Save"}),e.jsx("button",{className:"odm-cancel-btn",onClick:ce,disabled:N,children:"Cancel"})]})]}):e.jsxs("div",{className:"info-value-flex",children:[i&&!c&&e.jsx(i,{size:13,style:{color:"var(--text-tertiary)",flexShrink:0}}),e.jsx("span",{className:"info-value",children:s==="delivery_charge"&&d!==null?`৳${Number(d).toLocaleString()}`:U}),e.jsx("button",{className:"odm-edit-trigger",onClick:()=>ke(s),title:`Edit ${a}`,children:e.jsx(fe,{size:12})})]})]})},we=s=>{const i=[...String(s||"").matchAll(/(\d{2,5})/g)];if(i.length===0)return null;const o=Number(i[i.length-1][1]);return Number.isFinite(o)&&o>0?o:null},_e=()=>String(t.shipping_zone||"").trim().replace(/\s*\([^)]*\d[^)]*\)\s*/g," ").replace(/\s+/g," ").trim()||"Delivery Zone";(()=>{const s=we(t.shipping_zone);if(s!==null)return s;const a=Number(t.delivery_charge);if(Number.isFinite(a)&&a>0)return a;const i=Number(t.pricing_summary?.delivery_charge);return Number.isFinite(i)&&i>0?i:null})();const me=_e(),ue=s=>{const a=String(s||"").toLowerCase();return["confirmed","completed","delivered"].includes(a)?"success":a==="bulk exported"?"courier":["cancelled","returned","failed"].includes(a)?"danger":["pending","new","hold","pending call"].includes(a)?"warning":"neutral"},Ce=s=>{const a=String(s||"").toLowerCase();return["paid","success","completed"].includes(a)?"success":["failed","cancelled","refunded"].includes(a)?"danger":"warning"},L=s=>{navigator.clipboard.writeText(s)},pe=typeof t.ip_address=="string"?t.ip_address.trim():t.ip_address?String(t.ip_address):"",$=ve??t.notes??"",l=Se(t?.phone),he=l?.couriers&&typeof l.couriers=="object"?Object.entries(l.couriers).map(([s,a])=>{const i=a&&typeof a=="object"?a:{},o=Number(i.total_parcel??i.total??0)||0,c=Number(i.success_parcel??i.success_count??i.success??0)||0,w=Number(i.cancelled_parcel??i.cancelled_count??i.cancelled??0)||0,d=Number(i.success_ratio??i.ratio??0)||0;return{key:s,name:i.name||s,logo:i.logo||"",total:o,success:c,cancelled:w,ratio:Math.max(0,Math.min(100,d))}}).filter(s=>s.name).sort((s,a)=>a.ratio!==s.ratio?a.ratio-s.ratio:a.success!==s.success?a.success-s.success:a.total-s.total):[],ze=t.created_at?new Date(t.created_at).toLocaleString("en-GB",{day:"2-digit",month:"short",year:"numeric",hour:"numeric",minute:"2-digit",hour12:!0}):"N/A",ge=Array.isArray(t.order_lines_payload)&&t.order_lines_payload.length>0?t.order_lines_payload.map(s=>({name:s.product_name||"Unknown Product",quantity:s.quantity||1,size:s.size||"",price:Number(s.line_total??(s.unit_price||0)*(s.quantity||1))||0})):Array.isArray(t.ordered_items)&&t.ordered_items.length>0&&typeof t.ordered_items[0]=="object"?t.ordered_items.map(s=>({name:s.name||s.product_name||"Unknown Product",quantity:s.quantity||1,size:s.size||"",price:Number((s.price||0)*(s.quantity||1))||0})):[{name:t.product_name||"Unknown Product",quantity:t.quantity||1,size:t.size||"",price:Number(t.amount||0)||0}],De=()=>{const s=ge.map((i,o)=>{const c=i.size?`, Size: ${i.size}`:"";return`${o+1}. ${i.name} x${i.quantity}${c}, Price: ${i.price.toLocaleString()}`}).join(`
`),a=[`Customer Name: ${t.customer_name||"N/A"}`,`Phone: ${t.phone||"N/A"}`,`Address: ${t.address||"N/A"}`,`Amount: ${Number(t.amount||0).toLocaleString()}`,`Date: ${ze}`,"Product Details:",s].join(`
`);L(a),Q(!0),S.current&&window.clearTimeout(S.current),S.current=window.setTimeout(()=>{Q(!1)},1800)},Le=()=>{const s=Number(r.amount||0),i=(()=>{const T=(A=>{if(!A)return null;const P=String(A).match(/\(\s*৳?\s*(\d+)\s*\)/);return P?Number(P[1]):null})(r.shipping_zone);if(T!==null)return T;const g=Number(r.delivery_charge);if(Number.isFinite(g)&&g>0)return g;const x=Number(r.pricing_summary?.delivery_charge);return Number.isFinite(x)&&x>0?x:0})(),o=i>0?Math.max(0,s-i):s,c=window.open("","_blank");if(!c){alert("Popup blocker blocked invoice print. Please allow popups for this site.");return}const w=r.created_at?new Date(r.created_at).toLocaleDateString("en-GB",{day:"2-digit",month:"short",year:"numeric"}):new Date().toLocaleDateString("en-GB",{day:"2-digit",month:"short",year:"numeric"}),d=ge.map((m,T)=>{const g=Number(m.price||0),x=Number(m.quantity||1),A=x>0?Math.round(g/x):g,P=m.size?`<span class="item-size">Size: ${m.size}</span>`:"";return`
        <tr>
          <td style="text-align: center; border-bottom: 1px solid #e2e8f0; padding: 2mm 3mm;">${T+1}</td>
          <td style="border-bottom: 1px solid #e2e8f0; padding: 2mm 3mm;">
            <span style="font-weight: 600; color: #0f172a;">${m.name}</span>
            ${P}
          </td>
          <td style="text-align: center; border-bottom: 1px solid #e2e8f0; padding: 2mm 3mm;">${x}</td>
          <td style="text-align: right; border-bottom: 1px solid #e2e8f0; padding: 2mm 3mm;">৳${A.toLocaleString("en-BD")}</td>
          <td style="text-align: right; border-bottom: 1px solid #e2e8f0; padding: 2mm 3mm;">৳${g.toLocaleString("en-BD")}</td>
        </tr>
      `}).join(""),U=`
      <!DOCTYPE html>
      <html>
        <head>
          <title>Invoice - ${r.id}</title>
          <link rel="preconnect" href="https://fonts.googleapis.com">
          <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
          <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
          <style>
            @page {
              size: A4 portrait;
              margin: 0;
            }
            body {
              font-family: 'Inter', sans-serif;
              margin: 0;
              padding: 0;
              width: 210mm;
              height: 297mm;
              background-color: #ffffff;
              color: #1f2937;
              -webkit-print-color-adjust: exact;
              print-color-adjust: exact;
            }
            .invoice-wrapper {
              width: 210mm;
              height: 148.5mm;
              box-sizing: border-box;
              padding: 10mm 12mm;
              border-bottom: 1px dashed #94a3b8;
              display: flex;
              flex-direction: column;
              justify-content: space-between;
              background-color: #ffffff;
            }
            .invoice-header {
              display: flex;
              justify-content: space-between;
              align-items: flex-start;
              margin-bottom: 4mm;
            }
            .brand-section {
              text-align: left;
            }
            .brand-name {
              font-size: 16pt;
              font-weight: 800;
              letter-spacing: -0.5px;
              color: #0f172a;
              margin: 0;
              text-transform: uppercase;
            }
            .brand-subtitle {
              font-size: 8pt;
              color: #6b7280;
              margin: 1mm 0 0 0;
            }
            .invoice-title-block {
              text-align: right;
            }
            .invoice-title {
              font-size: 15pt;
              font-weight: 800;
              color: #0f172a;
              margin: 0;
              text-transform: uppercase;
            }
            .invoice-meta {
              font-size: 9pt;
              margin-top: 1mm;
              color: #4b5563;
              line-height: 1.4;
            }
            .details-container {
              display: grid;
              grid-template-columns: 1.2fr 0.8fr;
              gap: 6mm;
              margin-bottom: 4mm;
              background-color: #f8fafc;
              padding: 3mm 4mm;
              border-radius: 8px;
              border: 1px solid #e2e8f0;
            }
            .details-block-title {
              font-size: 8pt;
              font-weight: 700;
              text-transform: uppercase;
              color: #64748b;
              margin: 0 0 1.5mm 0;
              letter-spacing: 0.5px;
            }
            .details-text {
              font-size: 9pt;
              line-height: 1.4;
              margin: 0;
              color: #334155;
            }
            .table-container {
              flex-grow: 1;
              margin-bottom: 4mm;
            }
            table {
              width: 100%;
              border-collapse: collapse;
              font-size: 9pt;
            }
            th {
              background-color: #0f172a;
              color: #ffffff;
              font-weight: 700;
              text-transform: uppercase;
              font-size: 7.5pt;
              padding: 2mm 3mm;
            }
            .item-size {
              font-size: 7.5pt;
              background-color: #e2e8f0;
              color: #475569;
              padding: 0.5mm 1.5mm;
              border-radius: 4px;
              margin-left: 2mm;
              font-weight: 500;
              display: inline-block;
            }
            .summary-footer {
              display: grid;
              grid-template-columns: 1.1fr 0.9fr;
              gap: 8mm;
              align-items: flex-end;
            }
            .notes-block {
              font-size: 8pt;
              color: #64748b;
              line-height: 1.4;
            }
            .summary-row {
              display: flex;
              justify-content: space-between;
              padding: 1.5mm 0;
              color: #475569;
              border-bottom: 1px solid #f1f5f9;
            }
            .summary-row.grand-total {
              border-bottom: none;
              padding-top: 2.5mm;
              font-size: 11pt;
              font-weight: 800;
              color: #0f172a;
            }
            .footer-contact {
              margin-top: 3mm;
              text-align: center;
              font-size: 7.5pt;
              color: #94a3b8;
              border-top: 1px solid #f1f5f9;
              padding-top: 2mm;
            }
          </style>
        </head>
        <body>
          <div class="invoice-wrapper">
            <div class="invoice-header">
              <div class="brand-section">
                <h1 class="brand-name">RUST & REVIVE</h1>
                <p class="brand-subtitle">Premium Streetwear | Bangladesh</p>
              </div>
              <div class="invoice-title-block">
                <h2 class="invoice-title">Retail Invoice</h2>
                <div class="invoice-meta">
                  Invoice #: <strong>${r.id}</strong><br>
                  Date: <strong>${w}</strong>
                </div>
              </div>
            </div>

            <div class="details-container">
              <div>
                <h3 class="details-block-title">Bill To</h3>
                <p class="details-text">
                  <strong>Name:</strong> ${r.customer_name}<br>
                  <strong>Phone:</strong> ${r.phone}<br>
                  <strong>Address:</strong> ${r.address||"N/A"}
                </p>
              </div>
              <div>
                <h3 class="details-block-title">Shipping Details</h3>
                <p class="details-text">
                  <strong>Zone:</strong> ${me}<br>
                  <strong>Method:</strong> Home Delivery<br>
                  <strong>Payment:</strong> ${r.payment_status||"Unpaid"}
                </p>
              </div>
            </div>

            <div class="table-container">
              <table>
                <thead>
                  <tr>
                    <th style="width: 8%; text-align: center; border-top-left-radius: 4px; border-bottom-left-radius: 4px;">SL</th>
                    <th style="width: 52%; text-align: left;">Item Description</th>
                    <th style="width: 10%; text-align: center;">Qty</th>
                    <th style="width: 15%; text-align: right;">Unit Price</th>
                    <th style="width: 15%; text-align: right; border-top-right-radius: 4px; border-bottom-right-radius: 4px;">Total</th>
                  </tr>
                </thead>
                <tbody>
                  ${d}
                </tbody>
              </table>
            </div>

            <div class="summary-footer">
              <div class="notes-block">
                <h3 class="details-block-title" style="margin-bottom: 1mm;">Customer Notes</h3>
                <p style="margin: 0;">${r.notes||"Thank you for your purchase! We appreciate your support."}</p>
              </div>
              <div>
                <div class="summary-row">
                  <span>Subtotal</span>
                  <span>৳${o.toLocaleString("en-BD")}</span>
                </div>
                <div class="summary-row">
                  <span>Delivery Charge</span>
                  <span>৳${i.toLocaleString("en-BD")}</span>
                </div>
                <div class="summary-row grand-total">
                  <span>Total Payable</span>
                  <span>৳${s.toLocaleString("en-BD")}</span>
                </div>
              </div>
            </div>

            <div class="footer-contact">
              This is a computer-generated invoice. No signature required. &nbsp;|&nbsp; Support: +880-9612-444888 &nbsp;|&nbsp; rustandrevive.com
            </div>
          </div>
        </body>
      </html>
    `;c.document.write(U),c.document.close(),c.focus(),setTimeout(()=>{c.print(),c.close()},350)},$e=async()=>{if(!t?.id||!v?.id)return;const s=String(f||"").trim();Y(!0);try{const a=await V.appendOrderNote(t.id,s,v.id,re?.name||v?.email||"Unknown User",ne,"Order Note");X(a?.notes||""),y(a?.notes||"")}catch(a){console.error("Failed to save order note:",a),alert(a.message||"Failed to save note.")}finally{Y(!1)}};return e.jsx(Ke,{isOpen:b,onClose:I,title:`Order Details: #${r.id.replace("ORD-","")}`,children:e.jsxs("div",{className:"order-details-elite",children:[e.jsxs("div",{className:"elite-modal-tabs",style:{display:"flex",gap:"8px",borderBottom:"1px solid var(--border-color)",marginBottom:"16px",paddingBottom:"8px"},children:[e.jsxs("button",{type:"button",className:`elite-tab-btn ${u==="details"?"active":""}`,style:{padding:"8px 16px",borderRadius:"6px",border:"none",background:u==="details"?"rgba(13, 148, 136,0.12)":"transparent",color:u==="details"?"#0d9488":"var(--text-secondary)",fontSize:"13px",fontWeight:600,cursor:"pointer",display:"flex",alignItems:"center",gap:"6px",transition:"all 0.2s ease"},onClick:()=>B("details"),children:[e.jsx(xe,{size:15})," Details"]}),e.jsxs("button",{type:"button",className:`elite-tab-btn ${u==="history"?"active":""}`,style:{padding:"8px 16px",borderRadius:"6px",border:"none",background:u==="history"?"rgba(13, 148, 136,0.12)":"transparent",color:u==="history"?"#0d9488":"var(--text-secondary)",fontSize:"13px",fontWeight:600,cursor:"pointer",display:"flex",alignItems:"center",gap:"6px",transition:"all 0.2s ease"},onClick:()=>B("history"),children:[e.jsx(be,{size:15})," History / Audit Trail (",R.length,")"]})]}),e.jsxs("div",{className:"details-summary-grid",children:[e.jsxs("div",{className:"summary-main-card glass-card",children:[e.jsxs("div",{className:"card-header-flex",children:[e.jsxs("div",{className:"order-main-info",children:[e.jsx("span",{className:"order-label",children:"Order Reference"}),e.jsxs("div",{className:"order-id-copy",onClick:()=>L(t.id),children:[e.jsx("h3",{children:t.id}),e.jsx(M,{size:14,className:"copy-icon"})]})]}),e.jsx(J,{variant:ue(t.status),className:"status-badge-elite",children:t.status})]}),e.jsxs("div",{className:"quick-meta-row",children:[e.jsxs("div",{className:"meta-item",children:[e.jsx(Te,{size:14}),e.jsx("span",{children:new Date(t.created_at).toLocaleDateString()})]}),e.jsxs("div",{className:"meta-item",children:[e.jsx(Ae,{size:14}),e.jsx("span",{children:new Date(t.created_at).toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"})})]}),e.jsxs("div",{className:"meta-item",children:[e.jsx(Pe,{size:14}),e.jsx("span",{style:{display:"inline-flex",alignItems:"center",padding:"2px 8px",borderRadius:"999px",fontSize:"10.5px",fontWeight:700,letterSpacing:"0.03em",whiteSpace:"nowrap",border:"1px solid",...(()=>{const s=String(t.source||"").toLowerCase();return s.includes("facebook")||s==="fb"?{background:"rgba(24,119,242,0.1)",color:"#1877f2",borderColor:"rgba(24,119,242,0.22)"}:s.includes("tiktok")?{background:"rgba(0,0,0,0.07)",color:"#1a1a1a",borderColor:"rgba(0,0,0,0.14)"}:s.includes("instagram")?{background:"rgba(225,48,108,0.1)",color:"#e1306c",borderColor:"rgba(225,48,108,0.22)"}:s.includes("web")?{background:"rgba(13, 148, 136,0.1)",color:"#0d9488",borderColor:"rgba(13, 148, 136,0.22)"}:s.includes("direct")?{background:"rgba(16,185,129,0.1)",color:"#059669",borderColor:"rgba(16,185,129,0.22)"}:{background:"rgba(100,116,139,0.08)",color:"#64748b",borderColor:"rgba(100,116,139,0.18)"}})()},children:t.source||"Direct"})]}),e.jsxs("div",{className:"meta-item",children:[e.jsx("span",{children:"Payment:"}),e.jsx(J,{variant:Ce(t.payment_status),children:t.payment_status==="Paid"?"Paid":t.payment_status||"Pending"})]})]})]}),e.jsxs("div",{className:"amount-focus-card glass-card",children:[e.jsx("span",{className:"order-label",children:"Total Amount"}),e.jsxs("div",{className:"amount-value",children:[e.jsx(_,{size:20,className:"currency-icon-elite"}),Number(r.amount||0).toLocaleString()]}),e.jsxs("div",{className:"shipping-info",children:[me,(()=>{const s=Number(r?.delivery_charge)||Number(r?.pricing_summary?.delivery_charge);return s>0?e.jsxs("span",{className:"fee",children:["(",e.jsx(_,{size:12,className:"currency-icon-elite"}),s.toLocaleString(),")"]}):null})()]})]})]}),e.jsxs("div",{className:"details-content-sections",children:[u==="details"&&e.jsxs(e.Fragment,{children:[e.jsxs("div",{className:"section-row",children:[e.jsxs("div",{className:"details-section-card glass-card half",children:[e.jsxs("div",{className:"section-title",children:[e.jsxs("div",{className:"section-title-main",children:[e.jsx(xe,{size:18,className:"text-accent"}),e.jsx("span",{children:"Customer Information"})]}),e.jsxs("button",{type:"button",className:`section-copy-btn ${H?"copied":""}`,onClick:De,title:"Copy customer and order summary",children:[e.jsx(Ie,{size:14}),e.jsx("span",{children:H?"Copied":"Copy"})]})]}),e.jsxs("div",{className:"info-list",children:[e.jsxs("div",{className:"info-item",children:[e.jsx("span",{className:"info-label",children:"Name"}),e.jsx("span",{className:"info-value",children:r.customer_name})]}),e.jsx(F,{field:"phone",label:"Phone",icon:Re,type:"tel"}),e.jsxs("div",{className:"info-item",children:[e.jsx("span",{className:"info-label",children:"IP Address"}),e.jsx("span",{className:`info-value ip-address-value ${pe?"":"muted"}`,children:pe||"Not captured"})]}),e.jsx(F,{field:"address",label:"Delivery Address",icon:Ee,multiline:!0}),e.jsx(F,{field:"delivery_charge",label:"Delivery Charge",icon:W,type:"number"}),e.jsxs("div",{className:"info-item vertical",children:[e.jsx("span",{className:"info-label",children:"Order Note"}),e.jsxs("div",{className:"order-note-editor",children:[e.jsx("textarea",{className:"order-note-textarea",value:f,onChange:s=>y(s.target.value),placeholder:"Add or update a single important call note for this order",rows:4}),e.jsxs("div",{className:"quick-templates-container",style:{marginTop:"8px",marginBottom:"8px"},children:[e.jsx("span",{style:{fontSize:"11px",fontWeight:600,color:"var(--text-secondary)",display:"block",marginBottom:"4px"},children:"QUICK TEMPLATES (Click to add)"}),e.jsxs("div",{className:"quick-templates-list",style:{display:"flex",flexWrap:"wrap",gap:"6px"},children:[["Customer busy — call after 30 mins","Wrong address — needs correction","Confirmed. Delivery before 7 PM"].map((s,a)=>e.jsx("button",{type:"button",className:"tpl-badge",style:{padding:"4px 8px",borderRadius:"4px",border:"1px solid var(--border-color)",background:"var(--bg-card-secondary)",color:"var(--text-primary)",fontSize:"11px",cursor:"pointer",display:"inline-flex",alignItems:"center",transition:"all 0.15s ease"},onClick:()=>se(s),children:s},a)),z.map((s,a)=>e.jsxs("button",{type:"button",className:"tpl-badge custom-tpl",style:{padding:"4px 8px",borderRadius:"4px",border:"1px solid rgba(13, 148, 136,0.3)",background:"rgba(13, 148, 136,0.06)",color:"#0d9488",fontSize:"11px",cursor:"pointer",display:"inline-flex",alignItems:"center",gap:"4px",transition:"all 0.15s ease"},onClick:()=>se(s),children:[e.jsx("span",{children:s}),e.jsx("span",{style:{color:"#ef4444",marginLeft:"2px",fontWeight:"bold",fontSize:"10px",display:"inline-flex",alignItems:"center",justifyContent:"center",width:"12px",height:"12px",borderRadius:"50%"},onClick:i=>je(a,i),title:"Delete template",children:"×"})]},`custom-${a}`))]}),f.trim()&&e.jsx("div",{style:{marginTop:"6px",textAlign:"right"},children:e.jsx("button",{type:"button",style:{fontSize:"10.5px",color:"#0d9488",background:"none",border:"none",cursor:"pointer",fontWeight:600,textDecoration:"underline"},onClick:()=>{const s=f.trim();if(s&&!z.includes(s)&&s.length<100){const a=[...z,s];ee(a),localStorage.setItem("orderflow_custom_notes_templates",JSON.stringify(a))}},title:"Save current note text as template",children:"+ Save current note as template"})})]}),e.jsxs("div",{className:"order-note-actions",children:[e.jsx(C,{variant:"secondary",size:"sm",onClick:()=>y(String($||"")),disabled:E,children:"Reset"}),e.jsx(C,{variant:"primary",size:"sm",onClick:$e,disabled:E||f===String($||""),children:E?"Saving...":"Save Note"})]})]})]}),$&&e.jsxs("div",{className:"order-notes-box prominent",children:[e.jsx("span",{className:"notes-label",children:"Current Note:"}),e.jsx("p",{children:$})]})]})]}),e.jsxs("div",{className:"details-section-card glass-card half",children:[e.jsxs("div",{className:"section-title",children:[e.jsx(Be,{size:18,className:"text-accent"}),e.jsx("span",{children:"Ordered Products"})]}),e.jsx("div",{className:"product-scroll-list",children:Array.isArray(t.ordered_items)&&t.ordered_items.length>0?t.ordered_items.map((s,a)=>e.jsxs("div",{className:"order-product-card glass-card",children:[e.jsxs("div",{className:"product-qty-badge",children:[s.quantity,"x"]}),e.jsxs("div",{className:"product-main-info",children:[e.jsxs("div",{className:"product-name-row",children:[e.jsx("span",{className:"name",children:s.name}),s.toyBoxNumber&&e.jsxs("span",{className:"box-tag",children:["Box #",s.toyBoxNumber]})]}),s.size&&e.jsxs("div",{className:"product-meta-detail",children:["Size: ",e.jsx("span",{className:"highlight",children:s.size}),s.color&&s.color!=="None"&&e.jsxs("span",{style:{marginLeft:"12px"},children:["Color: ",e.jsx("span",{className:"highlight",children:s.color})]})]})]}),e.jsxs("div",{className:"product-price-column",children:[e.jsxs("div",{className:"unit-price",children:["@",e.jsx(_,{size:10,className:"currency-icon-elite"}),Number(s.price||0).toLocaleString()]}),e.jsxs("div",{className:"total-price",children:[e.jsx(_,{size:12,className:"currency-icon-elite"}),Number((s.price||0)*(s.quantity||1)).toLocaleString()]})]})]},a)):e.jsxs("div",{className:"order-product-card glass-card",children:[e.jsxs("div",{className:"product-qty-badge",children:[t.quantity||1,"x"]}),e.jsxs("div",{className:"product-main-info",children:[e.jsx("div",{className:"product-name-row",children:e.jsx("span",{className:"name",children:t.product_name})}),t.size&&e.jsxs("div",{className:"product-meta-detail",children:["Size: ",e.jsx("span",{className:"highlight",children:t.size}),t.color&&t.color!=="None"&&e.jsxs("span",{style:{marginLeft:"12px"},children:["Color: ",e.jsx("span",{className:"highlight",children:t.color})]})]})]}),e.jsx("div",{className:"product-price-column",children:e.jsxs("div",{className:"total-price",children:[e.jsx(_,{size:12,className:"currency-icon-elite"}),Number(t.amount||0).toLocaleString()]})})]})})]})]}),e.jsxs("div",{className:"details-section-card glass-card full-width",children:[e.jsxs("div",{className:"section-title",style:{display:"flex",justifyContent:"space-between",alignItems:"center"},children:[e.jsxs("div",{className:"section-title-main",children:[e.jsx(W,{size:18,className:"text-accent"}),e.jsx("span",{children:"Courier Ratio Intelligence"})]}),e.jsxs("div",{style:{display:"flex",alignItems:"center",gap:"8px"},children:[l?.fetchedAt&&e.jsxs("span",{className:"courier-ratio-updated",style:{fontSize:"11px",color:"var(--text-tertiary)"},children:["Synced ",new Date(l.fetchedAt).toLocaleString("en-GB",{day:"2-digit",month:"short",hour:"numeric",minute:"2-digit",hour12:!0})]}),t.phone&&e.jsx("button",{type:"button",style:{display:"inline-flex",alignItems:"center",gap:"4px",padding:"4px 8px",borderRadius:"6px",border:"1px solid var(--border-color)",background:"var(--bg-card-secondary)",color:"var(--text-primary)",fontSize:"11px",fontWeight:500,cursor:"pointer",transition:"all 0.2s"},onClick:s=>{s.stopPropagation(),q(t.phone,!0)},disabled:l?.loading,children:l?.loading?e.jsxs(e.Fragment,{children:[e.jsx(Oe,{size:12,style:{animation:"spin 1s linear infinite"}}),e.jsx("span",{children:"Syncing..."})]}):e.jsxs(e.Fragment,{children:[e.jsx(qe,{size:12}),e.jsx("span",{children:"Sync Now"})]})})]})]}),t.phone?l?.loading?e.jsx("div",{className:"courier-ratio-empty",children:"Checking courier ratio for this number..."}):l?.error?e.jsxs("div",{className:"courier-ratio-empty text-red-500",style:{color:"var(--danger-color)",display:"flex",flexDirection:"column",gap:"8px",alignItems:"center",padding:"16px 8px"},children:[e.jsx(Fe,{size:20}),e.jsx("span",{style:{fontSize:"0.85rem",textAlign:"center",lineHeight:"1.4"},children:l.raw?.error||l.raw?.message||"Courier ratio data is not available right now."})]}):l?.fetched?e.jsxs("div",{className:"courier-ratio-stack",children:[e.jsxs("div",{className:"courier-ratio-metrics",children:[e.jsxs("div",{className:"courier-ratio-metric",children:[e.jsx("span",{className:"courier-ratio-label",children:"Success Ratio"}),e.jsxs("strong",{children:[Number(l.ratio||0).toFixed(0),"%"]})]}),e.jsxs("div",{className:"courier-ratio-metric",children:[e.jsx("span",{className:"courier-ratio-label",children:"Total Parcels"}),e.jsx("strong",{children:Number(l.total||0)})]}),e.jsxs("div",{className:"courier-ratio-metric",children:[e.jsx("span",{className:"courier-ratio-label",children:"Successful"}),e.jsx("strong",{children:Number(l.success_count||0)})]}),e.jsxs("div",{className:"courier-ratio-metric",children:[e.jsx("span",{className:"courier-ratio-label",children:"Cancelled"}),e.jsx("strong",{children:Number(l.cancelled||0)})]}),e.jsxs("div",{className:"courier-ratio-metric",children:[e.jsx("span",{className:"courier-ratio-label",children:"Risk Level"}),e.jsx("strong",{className:`courier-risk-tag ${l.riskLevel||"new"}`,children:String(l.riskLevel||"new").replace(/_/g," ")})]})]}),he.length>0&&e.jsxs("div",{className:"courier-breakdown-table-wrap",children:[e.jsxs("div",{className:"courier-breakdown-table-head",children:[e.jsx("span",{children:"Logo"}),e.jsx("span",{children:"Courier"}),e.jsx("span",{children:"Total"}),e.jsx("span",{children:"Success"}),e.jsx("span",{children:"Cancelled"}),e.jsx("span",{children:"Success Ratio"})]}),e.jsx("div",{className:"courier-breakdown-table-body",children:he.map(s=>e.jsxs("div",{className:"courier-breakdown-row",children:[e.jsxs("div",{className:"courier-logo-cell",children:[s.logo?e.jsx("img",{src:s.logo,alt:`${s.name} logo`,className:"courier-logo-image",loading:"lazy",onError:a=>{a.currentTarget.style.display="none";const i=a.currentTarget.parentElement?.querySelector(".courier-logo-fallback");i&&i.removeAttribute("hidden")}}):null,e.jsx("span",{className:"courier-logo-fallback",hidden:!!s.logo,children:String(s.name||"?").slice(0,2).toUpperCase()})]}),e.jsx("div",{className:"courier-name-cell",children:s.name}),e.jsx("div",{className:"courier-stat-cell",children:s.total}),e.jsx("div",{className:"courier-stat-cell success",children:s.success}),e.jsx("div",{className:"courier-stat-cell cancelled",children:s.cancelled}),e.jsxs("div",{className:"courier-ratio-cell",children:[e.jsxs("span",{children:[s.ratio.toFixed(1),"%"]}),e.jsx("div",{className:"courier-ratio-bar",children:e.jsx("div",{className:"courier-ratio-bar-fill",style:{width:`${s.ratio}%`}})})]})]},s.key))})]})]}):e.jsx("div",{className:"courier-ratio-empty",children:"Courier ratio check has not completed yet."}):e.jsx("div",{className:"courier-ratio-empty",children:"No customer phone found for courier ratio lookup."})]}),t.tracking_id&&e.jsxs("div",{className:"details-section-card glass-card full-width",children:[e.jsxs("div",{className:"section-title",children:[e.jsx(W,{size:18,className:"text-accent"}),e.jsx("span",{children:"Logistics & Courier Details"})]}),e.jsxs("div",{className:"logistics-grid",children:[e.jsxs("div",{className:"log-item",children:[e.jsx("span",{className:"info-label",children:"Courier Service"}),e.jsx("span",{className:"info-value",children:"Steadfast Logistics"})]}),e.jsxs("div",{className:"log-item",children:[e.jsx("span",{className:"info-label",children:"Steadfast ID"}),e.jsx("div",{className:"tracking-badge-group",children:e.jsxs("div",{className:"tracking-id-copy",onClick:()=>L(t.courier_assigned_id),children:[e.jsx("code",{children:t.courier_assigned_id||"Sync Required"}),e.jsx(M,{size:12,className:"copy-icon"})]})})]}),e.jsxs("div",{className:"log-item",children:[e.jsx("span",{className:"info-label",children:"Tracking Number"}),e.jsxs("div",{className:"tracking-badge-group",children:[e.jsxs("div",{className:"tracking-id-copy",onClick:()=>L(t.tracking_id),children:[e.jsx("code",{children:t.tracking_id||"N/A"}),e.jsx(M,{size:12,className:"copy-icon"})]}),t.tracking_id&&e.jsxs("a",{href:`https://portal.steadfast.com.bd/tracking/${t.tracking_id}`,target:"_blank",rel:"noreferrer",className:"tracking-external-link",children:[e.jsx(Ue,{size:14})," ",e.jsx("span",{children:"Portal"})]})]})]}),e.jsxs("div",{className:"log-item",children:[e.jsx("span",{className:"info-label",children:"Current Status"}),e.jsx(J,{variant:ue(t.courier_status),children:t.courier_status||"Checking..."})]})]})]})]}),u==="history"&&e.jsxs("div",{className:"details-section-card glass-card full-width",children:[e.jsxs("div",{className:"section-title",children:[e.jsx(be,{size:18,className:"text-accent"}),e.jsx("span",{children:"Activity Timeline & Audit Trail"})]}),ye?e.jsx("div",{className:"timeline-loading",children:"Syncing history..."}):R.length===0?e.jsx("div",{className:"timeline-empty",children:"No activity records found for this order."}):e.jsx("div",{className:"elite-timeline",children:R.filter(s=>String(s.action_description||"").trim()).map((s,a)=>e.jsxs("div",{className:"timeline-entry",children:[e.jsx("div",{className:"entry-point"}),e.jsxs("div",{className:"entry-content",children:[e.jsxs("div",{className:"entry-header",children:[e.jsx("span",{className:"entry-time",children:new Date(s.timestamp).toLocaleString([],{dateStyle:"medium",timeStyle:"short"})}),e.jsxs("div",{className:"entry-user",children:[e.jsx("div",{className:"mini-avatar",children:(s.changed_by_user_name||"S").charAt(0)}),e.jsx("span",{children:s.changed_by_user_name||"System"})]})]}),e.jsx("div",{className:"entry-desc",children:s.action_description})]})]},s.id||a))})]})]}),e.jsxs("div",{className:"details-footer-actions",children:[e.jsxs(C,{variant:"ghost",onClick:Le,style:{marginRight:"auto",display:"inline-flex",alignItems:"center",gap:"8px"},children:[e.jsx(Me,{size:18}),e.jsx("span",{children:"Print Invoice"})]}),e.jsx(C,{variant:"secondary",onClick:I,icon:e.jsx(We,{size:18}),children:"Close Window"}),K&&e.jsx(C,{variant:"primary",onClick:()=>{I(),K(r)},icon:e.jsx(fe,{size:18}),children:"Edit Full Order"})]})]})})};export{ts as O};
